package com.utn.apirest.dto.usuario;

import com.utn.apirest.enums.Rol;

public record UsuarioResponse(
        Long id,
        String nombre,
        String apellido,
        String mail,
        String celular,
        Rol rol
) {}
