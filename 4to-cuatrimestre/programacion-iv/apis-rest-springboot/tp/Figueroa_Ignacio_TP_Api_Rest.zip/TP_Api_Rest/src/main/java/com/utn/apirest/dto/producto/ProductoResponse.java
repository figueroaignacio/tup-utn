package com.utn.apirest.dto.producto;

public record ProductoResponse(
        Long id,
        String nombre,
        Double precio,
        String descripcion,
        Integer stock,
        String imagen,
        Boolean disponible,
        Long categoriaId,
        String categoriaNombre
) {}
