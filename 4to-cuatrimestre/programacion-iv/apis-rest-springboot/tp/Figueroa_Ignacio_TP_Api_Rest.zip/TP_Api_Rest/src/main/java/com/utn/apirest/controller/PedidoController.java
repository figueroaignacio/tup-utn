package com.utn.apirest.controller;

import com.utn.apirest.dto.pedido.PedidoRequest;
import com.utn.apirest.dto.pedido.PedidoResponse;
import com.utn.apirest.enums.Estado;
import com.utn.apirest.service.PedidoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/pedidos")
@Tag(name = "Pedidos", description = "Operaciones sobre pedidos")
public class PedidoController {

    private final PedidoService service;

    public PedidoController(PedidoService service) {
        this.service = service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Crear pedido con sus detalles")
    public PedidoResponse crear(@Valid @RequestBody PedidoRequest request) {
        return service.crear(request);
    }

    @GetMapping
    @Operation(summary = "Listar pedidos")
    public List<PedidoResponse> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Buscar pedido por ID")
    public PedidoResponse buscarPorId(@PathVariable Long id) {
        return service.buscarPorId(id);
    }

    @PatchMapping("/{id}/estado")
    @Operation(summary = "Actualizar estado de un pedido")
    public PedidoResponse cambiarEstado(
            @PathVariable Long id,
            @RequestParam Estado estado) {
        return service.cambiarEstado(id, estado);
    }
}
