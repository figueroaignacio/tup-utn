package com.utn.apirest.controller;

import com.utn.apirest.dto.usuario.UsuarioRequest;
import com.utn.apirest.dto.usuario.UsuarioResponse;
import com.utn.apirest.service.UsuarioService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/usuarios")
@Tag(name = "Usuarios", description = "Operaciones sobre usuarios")
public class UsuarioController {

    private final UsuarioService service;

    public UsuarioController(UsuarioService service) {
        this.service = service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Crear usuario")
    public UsuarioResponse crear(@Valid @RequestBody UsuarioRequest request) {
        return service.crear(request);
    }

    @GetMapping
    @Operation(summary = "Listar usuarios o buscar por mail")
    public List<UsuarioResponse> listar(@RequestParam(required = false) String mail) {
        return mail == null ? service.listar() : List.of(service.buscarPorMail(mail));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Buscar usuario por ID")
    public UsuarioResponse buscarPorId(@PathVariable Long id) {
        return service.buscarPorId(id);
    }
}
