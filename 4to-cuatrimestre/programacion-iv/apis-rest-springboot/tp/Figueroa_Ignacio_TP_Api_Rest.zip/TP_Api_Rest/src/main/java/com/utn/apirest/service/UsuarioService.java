package com.utn.apirest.service;

import com.utn.apirest.dto.usuario.UsuarioRequest;
import com.utn.apirest.dto.usuario.UsuarioResponse;
import com.utn.apirest.entity.Usuario;
import com.utn.apirest.exception.BusinessException;
import com.utn.apirest.exception.ResourceNotFoundException;
import com.utn.apirest.repository.UsuarioRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class UsuarioService {

    private final UsuarioRepository repository;

    public UsuarioService(UsuarioRepository repository) {
        this.repository = repository;
    }

    @Transactional
    public UsuarioResponse crear(UsuarioRequest request) {
        if (repository.findByMailIgnoreCase(request.mail()).isPresent()) {
            throw new BusinessException("Ya existe un usuario con el mail: " + request.mail());
        }

        Usuario usuario = new Usuario();
        usuario.setNombre(request.nombre());
        usuario.setApellido(request.apellido());
        usuario.setMail(request.mail());
        usuario.setCelular(request.celular());
        usuario.setContraseña(request.contraseña());
        usuario.setRol(request.rol());

        return toResponse(repository.save(usuario));
    }

    @Transactional(readOnly = true)
    public UsuarioResponse buscarPorId(Long id) {
        return toResponse(repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado: " + id)));
    }

    @Transactional(readOnly = true)
    public UsuarioResponse buscarPorMail(String mail) {
        return toResponse(repository.findByMailIgnoreCase(mail)
                .orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado con mail: " + mail)));
    }

    @Transactional(readOnly = true)
    public List<UsuarioResponse> listar() {
        return repository.findAll().stream().map(this::toResponse).toList();
    }

    private UsuarioResponse toResponse(Usuario u) {
        return new UsuarioResponse(u.getId(), u.getNombre(), u.getApellido(),
                u.getMail(), u.getCelular(), u.getRol());
    }
}
