package com.utn.apirest.service;

import com.utn.apirest.dto.producto.ProductoRequest;
import com.utn.apirest.dto.producto.ProductoResponse;
import com.utn.apirest.entity.Categoria;
import com.utn.apirest.entity.Producto;
import com.utn.apirest.exception.ResourceNotFoundException;
import com.utn.apirest.repository.CategoriaRepository;
import com.utn.apirest.repository.ProductoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ProductoService {

    private final ProductoRepository productoRepository;
    private final CategoriaRepository categoriaRepository;

    public ProductoService(ProductoRepository productoRepository, CategoriaRepository categoriaRepository) {
        this.productoRepository = productoRepository;
        this.categoriaRepository = categoriaRepository;
    }

    @Transactional
    public ProductoResponse crear(ProductoRequest request) {
        Categoria categoria = categoriaRepository.findById(request.categoriaId())
                .orElseThrow(() -> new ResourceNotFoundException("Categoría no encontrada: " + request.categoriaId()));

        Producto producto = new Producto();
        aplicar(producto, request, categoria);
        return toResponse(productoRepository.save(producto));
    }

    @Transactional
    public ProductoResponse actualizar(Long id, ProductoRequest request) {
        Producto producto = productoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Producto no encontrado: " + id));
        Categoria categoria = categoriaRepository.findById(request.categoriaId())
                .orElseThrow(() -> new ResourceNotFoundException("Categoría no encontrada: " + request.categoriaId()));

        aplicar(producto, request, categoria);
        return toResponse(productoRepository.save(producto));
    }

    @Transactional(readOnly = true)
    public ProductoResponse buscarPorId(Long id) {
        return toResponse(productoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Producto no encontrado: " + id)));
    }

    @Transactional(readOnly = true)
    public List<ProductoResponse> listar() {
        return productoRepository.findAll().stream().map(this::toResponse).toList();
    }

    private void aplicar(Producto p, ProductoRequest r, Categoria c) {
        p.setNombre(r.nombre());
        p.setPrecio(r.precio());
        p.setDescripcion(r.descripcion());
        p.setStock(r.stock());
        p.setImagen(r.imagen());
        p.setDisponible(r.disponible());
        p.setCategoria(c);
    }

    private ProductoResponse toResponse(Producto p) {
        return new ProductoResponse(p.getId(), p.getNombre(), p.getPrecio(), p.getDescripcion(),
                p.getStock(), p.getImagen(), p.getDisponible(),
                p.getCategoria().getId(), p.getCategoria().getNombre());
    }
}
