package com.utn.apirest.dto.detalle;

public record DetallePedidoResponse(
        Long id,
        Long productoId,
        String productoNombre,
        Integer cantidad,
        Double subtotal
) {}
