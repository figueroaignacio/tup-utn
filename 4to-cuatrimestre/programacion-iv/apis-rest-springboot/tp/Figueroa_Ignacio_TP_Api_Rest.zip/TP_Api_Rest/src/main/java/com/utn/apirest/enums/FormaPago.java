package com.utn.apirest.enums;

public enum FormaPago {
    TARJETA,
    TRANSFERENCIA,
    EFECTIVO
}
