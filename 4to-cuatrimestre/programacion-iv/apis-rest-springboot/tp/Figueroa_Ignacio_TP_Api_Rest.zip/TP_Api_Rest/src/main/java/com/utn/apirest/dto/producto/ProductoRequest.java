package com.utn.apirest.dto.producto;

import jakarta.validation.constraints.*;

public record ProductoRequest(
        @NotBlank(message = "El nombre es obligatorio")
        String nombre,

        @NotNull(message = "El precio es obligatorio")
        @Positive(message = "El precio debe ser mayor a 0")
        Double precio,

        @NotBlank(message = "La descripción es obligatoria")
        String descripcion,

        @NotNull(message = "El stock es obligatorio")
        @PositiveOrZero(message = "El stock no puede ser negativo")
        Integer stock,

        @NotBlank(message = "La imagen es obligatoria")
        String imagen,

        @NotNull(message = "La disponibilidad es obligatoria")
        Boolean disponible,

        @NotNull(message = "La categoría es obligatoria")
        Long categoriaId
) {}
