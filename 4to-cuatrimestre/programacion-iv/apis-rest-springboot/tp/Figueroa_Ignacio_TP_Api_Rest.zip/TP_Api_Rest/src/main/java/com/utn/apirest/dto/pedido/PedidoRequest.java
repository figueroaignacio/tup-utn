package com.utn.apirest.dto.pedido;

import com.utn.apirest.dto.detalle.DetallePedidoRequest;
import com.utn.apirest.enums.FormaPago;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

import java.util.List;

public record PedidoRequest(
        @NotNull(message = "El usuario es obligatorio")
        Long usuarioId,

        @NotNull(message = "La forma de pago es obligatoria")
        FormaPago formaPago,

        @NotEmpty(message = "El pedido debe tener al menos un detalle")
        List<@Valid DetallePedidoRequest> detalles
) {}
