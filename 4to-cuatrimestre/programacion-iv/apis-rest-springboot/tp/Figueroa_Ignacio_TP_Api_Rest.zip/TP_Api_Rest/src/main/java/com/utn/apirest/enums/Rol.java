package com.utn.apirest.enums;

public enum Rol {
    ADMIN,
    USUARIO
}
