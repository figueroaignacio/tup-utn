package com.utn.apirest.enums;

public enum Estado {
    PENDIENTE,
    CONFIRMADO,
    TERMINADO,
    CANCELADO
}
