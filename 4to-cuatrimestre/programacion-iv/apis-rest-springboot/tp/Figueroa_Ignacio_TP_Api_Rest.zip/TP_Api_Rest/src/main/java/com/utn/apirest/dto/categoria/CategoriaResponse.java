package com.utn.apirest.dto.categoria;

public record CategoriaResponse(
        Long id,
        String nombre,
        String descripcion
) {}
