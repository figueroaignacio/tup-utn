package com.utn.apirest.entity;

public interface Calculable {
    void calcularTotal();
}
