package com.utn.apirest.dto.pedido;

import com.utn.apirest.dto.detalle.DetallePedidoResponse;
import com.utn.apirest.enums.Estado;
import com.utn.apirest.enums.FormaPago;

import java.time.LocalDate;
import java.util.List;

public record PedidoResponse(
        Long id,
        LocalDate fechaLocalDate,
        Estado estado,
        Double total,
        FormaPago formaPago,
        Long usuarioId,
        String usuarioMail,
        List<DetallePedidoResponse> detalles
) {}
