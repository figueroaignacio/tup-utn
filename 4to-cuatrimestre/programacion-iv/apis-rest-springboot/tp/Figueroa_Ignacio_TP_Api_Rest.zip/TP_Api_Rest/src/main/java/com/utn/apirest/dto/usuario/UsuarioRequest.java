package com.utn.apirest.dto.usuario;

import com.utn.apirest.enums.Rol;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record UsuarioRequest(
        @NotBlank(message = "El nombre es obligatorio")
        String nombre,

        @NotBlank(message = "El apellido es obligatorio")
        String apellido,

        @NotBlank(message = "El mail es obligatorio")
        @Email(message = "El mail no tiene un formato válido")
        String mail,

        @NotBlank(message = "El celular es obligatorio")
        String celular,

        @NotBlank(message = "La contraseña es obligatoria")
        @Size(min = 6, message = "La contraseña debe tener al menos 6 caracteres")
        String contraseña,

        @NotNull(message = "El rol es obligatorio")
        Rol rol
) {}
