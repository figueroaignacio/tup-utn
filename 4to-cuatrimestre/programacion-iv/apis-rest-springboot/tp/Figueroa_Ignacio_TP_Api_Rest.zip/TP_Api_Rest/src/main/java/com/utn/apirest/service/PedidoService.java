package com.utn.apirest.service;

import com.utn.apirest.dto.detalle.DetallePedidoRequest;
import com.utn.apirest.dto.detalle.DetallePedidoResponse;
import com.utn.apirest.dto.pedido.PedidoRequest;
import com.utn.apirest.dto.pedido.PedidoResponse;
import com.utn.apirest.entity.*;
import com.utn.apirest.enums.Estado;
import com.utn.apirest.exception.BusinessException;
import com.utn.apirest.exception.ResourceNotFoundException;
import com.utn.apirest.repository.PedidoRepository;
import com.utn.apirest.repository.ProductoRepository;
import com.utn.apirest.repository.UsuarioRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class PedidoService {

    private final PedidoRepository pedidoRepository;
    private final UsuarioRepository usuarioRepository;
    private final ProductoRepository productoRepository;

    public PedidoService(PedidoRepository pedidoRepository,
                         UsuarioRepository usuarioRepository,
                         ProductoRepository productoRepository) {
        this.pedidoRepository = pedidoRepository;
        this.usuarioRepository = usuarioRepository;
        this.productoRepository = productoRepository;
    }

    @Transactional
    public PedidoResponse crear(PedidoRequest request) {
        Usuario usuario = usuarioRepository.findById(request.usuarioId())
                .orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado: " + request.usuarioId()));

        Pedido pedido = new Pedido();
        pedido.setUsuario(usuario);
        pedido.setFormaPago(request.formaPago());
        pedido.setEstado(Estado.PENDIENTE);

        for (DetallePedidoRequest detalleRequest : request.detalles()) {
            Producto producto = productoRepository.findById(detalleRequest.productoId())
                    .orElseThrow(() -> new ResourceNotFoundException(
                            "Producto no encontrado: " + detalleRequest.productoId()));

            if (!Boolean.TRUE.equals(producto.getDisponible())) {
                throw new BusinessException("El producto no está disponible: " + producto.getNombre());
            }

            if (producto.getStock() < detalleRequest.cantidad()) {
                throw new BusinessException("Stock insuficiente para el producto: " + producto.getNombre());
            }

            DetallePedido detalle = new DetallePedido();
            detalle.setProducto(producto);
            detalle.setCantidad(detalleRequest.cantidad());
            detalle.setSubtotal(producto.getPrecio() * detalleRequest.cantidad());

            pedido.addDetallePedido(detalle);
            producto.setStock(producto.getStock() - detalleRequest.cantidad());
            producto.setDisponible(producto.getStock() > 0);
        }

        pedido.calcularTotal();
        return toResponse(pedidoRepository.save(pedido));
    }

    @Transactional(readOnly = true)
    public PedidoResponse buscarPorId(Long id) {
        Pedido pedido = pedidoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Pedido no encontrado: " + id));
        return toResponse(pedido);
    }

    @Transactional(readOnly = true)
    public List<PedidoResponse> listar() {
        return pedidoRepository.findAll().stream().map(this::toResponse).toList();
    }

    @Transactional
    public PedidoResponse cambiarEstado(Long id, Estado estado) {
        Pedido pedido = pedidoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Pedido no encontrado: " + id));
        pedido.setEstado(estado);
        return toResponse(pedidoRepository.save(pedido));
    }

    private PedidoResponse toResponse(Pedido p) {
        List<DetallePedidoResponse> detalles = p.getDetalles().stream()
                .map(d -> new DetallePedidoResponse(
                        d.getId(),
                        d.getProducto().getId(),
                        d.getProducto().getNombre(),
                        d.getCantidad(),
                        d.getSubtotal()))
                .toList();

        return new PedidoResponse(
                p.getId(),
                p.getFechaLocalDate(),
                p.getEstado(),
                p.getTotal(),
                p.getFormaPago(),
                p.getUsuario().getId(),
                p.getUsuario().getMail(),
                detalles
        );
    }
}
