# TP API REST - Programación IV

Proyecto Spring Boot para resolver el Trabajo Práctico de API REST de Programación IV.

## Tecnologías

- Spring Boot 3.3.5
- Spring Web
- Spring Data JPA
- H2 Database (memoria)
- Bean Validation
- Manejo global de excepciones con `@RestControllerAdvice`
- Swagger/OpenAPI (`springdoc-openapi-starter-webmvc-ui:2.5.0`)
- Java 17
- Gradle

## Arquitectura

El proyecto está organizado en capas:

```text
src/main/java/com/utn/apirest/
├── config/
├── controller/
├── dto/
├── entity/
├── enums/
├── exception/
├── repository/
└── service/
```

## Cómo ejecutar

Abrir el proyecto con IntelliJ IDEA, Spring Tool Suite o Eclipse como proyecto Gradle y ejecutar:

```bash
./gradlew bootRun
```

También se puede ejecutar la clase:

`com.utn.apirest.ApiRestApplication`

La aplicación queda disponible en:

`http://localhost:8080`

## Swagger

Con la aplicación ejecutándose:

- Swagger UI: `http://localhost:8080/swagger-ui.html`
- OpenAPI JSON: `http://localhost:8080/v3/api-docs`

## H2

Con la aplicación ejecutándose:

- Consola H2: `http://localhost:8080/h2-console`
- JDBC URL: `jdbc:h2:mem:apirest`
- Usuario: `sa`
- Contraseña: dejar vacía

La base es en memoria, por lo que los datos se reinician al detener la aplicación.

## Endpoints principales

### Usuarios

- `POST /api/usuarios`
- `GET /api/usuarios`
- `GET /api/usuarios/{id}`
- `GET /api/usuarios?mail=correo@ejemplo.com`

### Categorías

- `POST /api/categorias`
- `GET /api/categorias`
- `GET /api/categorias/{id}`
- `PUT /api/categorias/{id}`

### Productos

- `POST /api/productos`
- `GET /api/productos`
- `GET /api/productos/{id}`
- `PUT /api/productos/{id}`

### Pedidos

- `POST /api/pedidos`
- `GET /api/pedidos`
- `GET /api/pedidos/{id}`
- `PATCH /api/pedidos/{id}/estado?estado=CONFIRMADO`

## Orden recomendado para probar el TP

1. Crear 2 usuarios.
2. Crear 3 categorías.
3. Crear 10 productos indicando el `categoriaId` correspondiente.
4. Crear 3 pedidos con al menos 2 detalles cada uno.
5. Actualizar una categoría con `PUT`.
6. Buscar un usuario por ID.
7. Buscar un usuario por mail.
8. Abrir Swagger y verificar la documentación.

En `postman/TP-API-REST.postman_collection.json` se incluye una colección preparada para realizar el flujo completo.

## Ejemplo: crear usuario

```json
{
  "nombre": "Juan",
  "apellido": "Pérez",
  "mail": "juan.perez@email.com",
  "celular": "1122334455",
  "contraseña": "123456",
  "rol": "USUARIO"
}
```

## Ejemplo: crear producto

```json
{
  "nombre": "Teclado mecánico",
  "precio": 85000,
  "descripcion": "Teclado mecánico para PC",
  "stock": 10,
  "imagen": "https://example.com/teclado.jpg",
  "disponible": true,
  "categoriaId": 1
}
```

## Ejemplo: crear pedido

El subtotal se calcula en el servidor a partir del precio actual del producto y la cantidad enviada.

```json
{
  "usuarioId": 1,
  "formaPago": "TARJETA",
  "detalles": [
    {
      "productoId": 1,
      "cantidad": 2
    },
    {
      "productoId": 2,
      "cantidad": 1
    }
  ]
}
```

## Nota sobre `target/`

No se incluye la carpeta `target/` ni otros archivos generados de compilación en la entrega.

